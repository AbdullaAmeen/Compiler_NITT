%{
    #include<stdio.h>
    #include<string.h>
    extern FILE* yyin;
    char name[100][20],datatype[100][20],scope[100][10], lexeme[100];int offset[100],size[100];
    int i=0,count=0;
    extern char* yytext;
    
%}
%token INT CHART FLOAT DOUBLE
%token INTEGER CHAR NUMERIC
%token IDENTIFIER ARRAYDEC 

%start S
%%

S : S1              {printf("\nExpression is VALID \n");return 0;}
S1 : S2 S1
    | S2
S2 : INT R1 ';'
    | FLOAT R2 ';'
    | CHART R3 ';'
    | DOUBLE R4 ';'

R1 : R1 ',' IDENTIFIER  {strcpy(lexeme,yylval);} OPT {insert(0);}
    | IDENTIFIER        {strcpy(lexeme,yylval);} OPT {insert(0);} 
R2 : R2 ',' IDENTIFIER  {strcpy(lexeme,yylval);} OPT {insert(1);}
    | IDENTIFIER        {strcpy(lexeme,yylval);} OPT {insert(1);}
R3 : R3 ',' IDENTIFIER  {strcpy(lexeme,yylval);} OPT {insert(2);}
    |IDENTIFIER         {strcpy(lexeme,yylval);} OPT {insert(2);}
R4 : R4 ',' IDENTIFIER  {strcpy(lexeme,yylval);} OPT {insert(3);}
    |IDENTIFIER         {strcpy(lexeme,yylval);} OPT {insert(3);}

OPT : '=' INTEGER        
    | '=' NUMERIC
    | '=' CHAR
    |                   ;

%%

int main(){
    yyin=fopen("q2Input.c","r");
    yyparse();
    printf("\n\t\t\t\tSymbol Table\n\n");
    printf("Identifier\t|Type\t\t|Offset\t\t|Size\t\t|Scope\n");
    for(i=0;i<count;i++){
        printf("%s\t\t|%s\t\t|%d\t\t|%d\t\t|%s\n",name[i],datatype[i],offset[i],size[i],scope[i]);
    }
    printf("\n");
    return 0;
}
void insert(int type){
    for(i=0;i<count;i++){
        if(strcmp(lexeme,name[i])==0)
        {
                printf("ERROR: VAR ALREADY FOUND:%s\n",lexeme);
                exit(0);
        }
    }

    strcpy(name[count],lexeme);
    if(type==0){
        strcpy(datatype[count],"int");
        size[count]=2;
    }
    else if(type==1){
        strcpy(datatype[count],"float");
        size[count]=4; 
    }
    else if(type==2){
        strcpy(datatype[count],"char");
        size[count]=1;   
    }
    else{
        strcpy(datatype[count],"double");
        size[count]=8; 
    }

    if(count==0){
        offset[count]=0;
    }
    else{
        offset[count]=offset[count-1]+size[count-1];
    }

    strcpy(scope[count],"local");
    count++;
    
}
int calcSize(char *temp){
    char *result=temp+1;
    result[strlen(result)-1]='\0';
    return atoi(result);
} 
int yyerror(char* s) {
    printf("\nEnter VALID INPUT.\n");
}
int yywrap(){
    return 1;
}