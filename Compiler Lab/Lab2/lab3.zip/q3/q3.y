%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.tab.h"
%}

%union {
    int intval;
    char *strval;
}

%token IF ELSE LPAREN RPAREN LBRACE RBRACE EQUAL NOTEQUAL GREATER GREATEREQUAL LESS LESSEQUAL OR AND NOT SEMICOLON
%token <intval> INT
%token <strval> IDENT

%type <intval> expr
%type <strval> statement

%%

program:
    | program statement SEMICOLON
    ;

statement:
    IF LPAREN expr RPAREN LBRACE program RBRACE
        { printf("if statement with condition: %d\n", $3); }
    | IF LPAREN expr RPAREN LBRACE program RBRACE ELSE LBRACE program RBRACE
        { printf("if-else statement with condition: %d\n", $3); }
    ;

expr:
    expr OR expr
        { $$ = $1 || $3; }
    | expr AND expr
        { $$ = $1 && $3; }
    | NOT expr
        { $$ = !$2; }
    | INT
        { $$ = $1; }
    | IDENT EQUAL INT
        { printf("variable assignment: %s = %d\n", $1, $3); }
    | IDENT NOTEQUAL INT
        { printf("variable comparison: %s != %d\n", $1, $3); }
    | IDENT GREATER INT
        { printf("variable comparison: %s > %d\n", $1, $3); }
    | IDENT GREATEREQUAL INT
        { printf("variable comparison: %s >= %d\n", $1, $3); }
    | IDENT LESS INT
        { printf("variable comparison: %s < %d\n", $1, $3); }
    | IDENT LESSEQUAL INT
        { printf("variable comparison: %s <= %d\n", $1, $3); }
    ;

%%

int main() {
    yyparse();
    return 0;
}

void yyerror(char *msg) {
    printf("Syntax error: %s\n", msg);
}

