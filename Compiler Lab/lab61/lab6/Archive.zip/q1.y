%{
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    int flag = 0;
    int yylex();
    int yyerror(const char *s);

    FILE *fp;

    struct variable{
        char name[32];
        int value;
    } vars[128];

    int var_count = 0;
    int var_no = 0;

    char* generate_var() {
        char *var = (char*)malloc(sizeof(char) * 32);
        sprintf(var, "var%d", var_no++);
        return var;
    }

    void set_var(char *name, int value){
        printf("In set_var\n");
        if(var_count > 127) yyerror("Too many variables");
        strcpy(vars[var_count].name, name);
        vars[var_count].value = value;
        var_count++;
    }
    int update_var(char *name, int value){
        int i;
        for(i = 0; i < var_count; i++){
            if(strcmp(vars[i].name, name) == 0){
                vars[i].value = value;
                return 1;
            }
        }
        char err[100] = "Undefined variable ";
        strcat(err, name);
        yyerror(err);
        return -1;
    }
    int get_var(char *name){
        int i;
        printf("In get_var\n");
        for(i = 0; i < var_count; i++){
            if(strcmp(vars[i].name, name) == 0){
                printf("Found variable %s\n", name);
                return vars[i].value;
            }
        }
        char err[100] = "Undefined variable ";
        strcat(err, name);
        yyerror(err);
        return -1;
    }

    struct Node {
        char* val;
        char* var_name;
        struct Node *left;
        struct Node* right;
    };

    struct Node* newNode(char* val, struct Node* left, struct Node* right){
        struct Node* node = (struct Node*)malloc(sizeof(struct Node));
        node->val = strdup(val);
        node->left = left;
        node->right = right;
        if(left != NULL || right != NULL) {
            if(strcmp(val, "=") != 0)
                node->var_name = strdup(generate_var());
        } else {
            node->var_name = strdup(val);
        }
        return node;
    }

    struct Node* root;
    void inorder(struct Node* root);
    void postorder(struct Node* root);
    void generate_icg(struct Node* root);
%}

%left   '='
%left   OR
%left   AND
%left   EE NE
%left   '<' '>' GE LE
%left   '+' '-'
%left   '*' '/' '%'
%left   '!'
%left   '(' ')'

%union 
{
    int num;
    char ch;
    char *str;
    struct Node* node;
}

%token  <str>   NUMBER
%token  <str>   IDENTIFIER
%token  <str>   DATATYPE
%type   <node>    Term
%type   <node>         Expressions
%type   <node>         Expression
%start           Expressions

%%
Expressions
: Expression {root = $1; inorder(root); generate_icg(root); var_no = 0; fprintf(fp, "\n"); printf(" postorder "); postorder(root); printf("\n"); }
| Expressions Expression {root = $2; inorder(root); generate_icg(root); var_no = 0; fprintf(fp, "\n"); printf(" postorder "); postorder(root); printf("\n");}
;

Expression  
: IDENTIFIER '=' Term ';' {$$ = newNode("=", newNode($1, NULL, NULL), $3);}
| DATATYPE IDENTIFIER '=' Term ';'{$$ = newNode("=", newNode($2, NULL, NULL), $4);}                
;

Term 
: Term '+' Term     {$$ = newNode("+", $1, $3);}
| Term '-' Term     {$$ = newNode("-", $1, $3);}
| Term '*' Term     {$$ = newNode("*", $1, $3);}
| Term '/' Term     {$$ = newNode("/", $1, $3);}
| Term '%' Term     {$$ = newNode("%", $1, $3);}
| Term AND Term     {$$ = newNode("&&", $1, $3);}
| Term OR Term      {$$ = newNode("||", $1, $3);}
| Term '<' Term     {$$ = newNode("<", $1, $3);}
| Term '>' Term     {$$ = newNode(">", $1, $3);}
| Term LE Term      {$$ = newNode("<=", $1, $3);}
| Term GE Term      {$$ = newNode(">=", $1, $3);}
| Term EE Term      {$$ = newNode("==", $1, $3);}
| Term NE Term      {$$ = newNode("!=", $1, $3);}
| '(' Term ')'      {$$ = newNode("()", $2, NULL);}
| '!' Term          {$$ = newNode("!", $2, NULL);}
| NUMBER            {$$ = newNode($1, NULL, NULL);}
| IDENTIFIER        {$$ = newNode($1, NULL, NULL);}
;
%%

void postorder(struct Node* root){
    if(root == NULL) return;
    postorder(root->left);
    postorder(root->right);
    printf("%s ", root->val);
}

void inorder(struct Node* root){
    if(root == NULL) return;
    inorder(root->left);
    printf("%s ", root->val);
    inorder(root->right);
}

void generate_icg(struct Node* root) {
    if(root == NULL || (root->left == NULL && root->right == NULL)) return;
    generate_icg(root->left);
    generate_icg(root->right);
    if(strcmp(root->val, "=") != 0)
        fprintf(fp, "%s = ", root->var_name);
    if(root->left != NULL) {
        fprintf(fp, "%s", root->left->var_name);
    }
    fprintf(fp, " %s ", root->val);
    if(root->right != NULL) {
        fprintf(fp, "%s\n", root->right->var_name);
    }
}

int main()
{
    fp = fopen("icg.txt", "w");
    /* printf("%s\n", generate_var()); */
    printf("\nEnter an expression with any of the binary operators:\n\n");
    yyparse();
    /* printf("\nPrinting Variables\n");
    for(int i = 0 ; i < var_count; i++) {
        printf("%s = %d\n", vars[i].name, vars[i].value);
    } */
    /* printf("%s\n", root->var_name); */
    if (flag == 0)
    {
        printf("\nEntered expression is Valid\n\n");
    }
    return 0;
}

int yyerror(const char *s)
{
    printf("\nError: %s\n\n", s);
    flag = 1;
    exit(1);
    return 0;
}
